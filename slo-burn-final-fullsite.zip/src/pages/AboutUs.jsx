const AboutUs = () => {
  return (
    <section className="bg-white text-gray-800 px-6 py-24">
      <div className="max-w-6xl mx-auto text-center">
        <h1 className="text-4xl font-bold mb-8 text-pink-600">About Us</h1>
        <p className="text-lg text-gray-700">
          Meet Dr. Sienna Olson and Dr. Jonathan Olson — blending chiropractic, movement science, and practical lifestyle design into one powerful prescription.
        </p>
      </div>
    </section>
  );
};

export default AboutUs;
