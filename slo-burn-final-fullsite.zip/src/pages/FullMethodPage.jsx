const FullMethodPage = () => {
  return (
    <section className="min-h-screen bg-gradient-to-b from-pink-50 via-white to-rose-100 text-gray-800 px-6 py-32 text-center">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-4xl font-bold text-pink-600 mb-6">The Full Method</h2>
        <p className="text-lg text-gray-600">
          This page could expand the core Rx1, Rx2, Rx3 frameworks into full programs, assessments, or transformation plans.
        </p>
      </div>
    </section>
  );
};

export default FullMethodPage;
